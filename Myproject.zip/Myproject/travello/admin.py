from django.contrib import admin
from .models import Destination
from travello.models import Blog
# Register your models here.

admin.site.register(Destination)
admin.site.register(Blog)
